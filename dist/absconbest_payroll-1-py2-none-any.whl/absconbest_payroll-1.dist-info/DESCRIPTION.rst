An open source system including a spreadsheet working perfectly with both Excel and Calc; and functions like generating a graph and report; tested to work well in Ubuntu 16.04 and Windows 10


