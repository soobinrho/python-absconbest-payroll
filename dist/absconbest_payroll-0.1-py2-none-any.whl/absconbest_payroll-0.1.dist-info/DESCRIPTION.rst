An open source time and payroll management system including a spreadsheet working perfectly with both Excel and Calc; and functions like generating a graph and report; tested to function perfectly on Ubuntu 16.04 and Windows 10


