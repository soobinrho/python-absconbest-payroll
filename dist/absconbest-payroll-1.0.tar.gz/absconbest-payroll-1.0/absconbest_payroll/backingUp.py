#import shutil
#import xlsxwriter

# Under Development
# set times as zero for some cells
# def edit_xlsx(workbook, location, value):
#     workbook = xlsxwriter.Workbook(workbook)
#     #workbook = xlsxwriter.Workbook('payroll_management.xlsx')
#     worksheet = workbook.add_worksheet()
#     worksheet.write(location, value)
#     #worksheet.write('A1', 'Hello world')
#     workbook.close()

